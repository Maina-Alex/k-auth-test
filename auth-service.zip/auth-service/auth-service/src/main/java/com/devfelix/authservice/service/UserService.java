package com.devfelix.authservice.service;

import com.devfelix.authservice.dto.UserDto;
import com.devfelix.authservice.model.MovieUser;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public interface UserService {
    Mono<MovieUser> createUser(UserDto userDto);
    Mono<MovieUser> getUser(long userId);
    Mono<Page<MovieUser>> getUsers(Pageable pageable);
    Mono<MovieUser> updateUser(UserDto userDto, long id);


}
