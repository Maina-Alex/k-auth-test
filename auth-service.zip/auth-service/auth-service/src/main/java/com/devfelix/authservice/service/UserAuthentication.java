package com.devfelix.authservice.service;

import com.devfelix.authservice.dto.AccessTokenWrapper;
import com.devfelix.authservice.dto.UserLogin;
import reactor.core.publisher.Mono;

public interface UserAuthentication {
    Mono<AccessTokenWrapper> loginUser(UserLogin userLogin);

    Mono<AccessTokenWrapper> validateToken(String token);

}
