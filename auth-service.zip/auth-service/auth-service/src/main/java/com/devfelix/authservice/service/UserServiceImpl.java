package com.devfelix.authservice.service;

import com.devfelix.authservice.dto.UserDto;
import com.devfelix.authservice.exception.UserServiceException;
import com.devfelix.authservice.model.MovieUser;
import com.devfelix.authservice.repository.MovieUserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserServiceImpl implements UserService{
    private final MovieUserRepository movieUserRepository;
    private final PasswordEncoder passwordEncoder;
    @Override
    public Mono<MovieUser> createUser(UserDto userDto) {
        return Mono.fromCallable(()-> {
            //validate if user exists
            boolean isUserPresent= movieUserRepository.existsByEmail(userDto.email());
            if(isUserPresent){
                // throw exception
                throw new UserServiceException("User already exists");
            }
            MovieUser newUser= MovieUser.builder()
                    .firstName(userDto.firstName())
                    .lastName(userDto.lastName())
                    .email(userDto.email())
                    .phone(userDto.phone())
                    .password(passwordEncoder.encode(userDto.password()))
                    .build();

            return movieUserRepository.save(newUser);
        }).publishOn(Schedulers.boundedElastic());
    }

    @Override
    public Mono<MovieUser> getUser(long userId) {
        return Mono.fromCallable(()-> movieUserRepository.findById(userId)
                .orElseThrow(()-> new UserServiceException("User not found"))).publishOn(Schedulers.boundedElastic());
    }

    @Override
    public Mono<Page<MovieUser>> getUsers(Pageable pageable) {
        return Mono.fromCallable(()-> movieUserRepository.findAll(pageable)).publishOn(Schedulers.boundedElastic());
    }

    @Override
    public Mono<MovieUser> updateUser(UserDto userDto, long id ) {
        return Mono.fromCallable(()-> {
            MovieUser user= movieUserRepository.findById(id)
                    .orElseThrow(()-> new UserServiceException("User not found"));
            if(userDto.firstName()!=null){
                user.setFirstName(userDto.firstName());
            }

            if(userDto.lastName()!=null){
                user.setLastName(userDto.lastName());
            }

            if(userDto.phone()!=null){
                user.setPhone(userDto.phone());
            }
            return movieUserRepository.save(user);
        }).publishOn(Schedulers.boundedElastic());
    }

}
