package com.devfelix.authservice.repository;

import com.devfelix.authservice.model.MovieUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MovieUserRepository extends JpaRepository<MovieUser,Long> {

    boolean existsByEmail(String email);

    Optional<MovieUser> findByEmail(String email);
}
